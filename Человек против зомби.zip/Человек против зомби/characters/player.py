from PyQt5.QtWidgets import QGraphicsPixmapItem, QMainWindow, QGraphicsScene, QGraphicsView, QApplication
from PyQt5.QtGui import QPixmap, QKeyEvent
from PyQt5.QtCore import Qt

class Player(QGraphicsPixmapItem):
    def __init__(self):
        super().__init__()

        self.setPixmap(QPixmap("images/player.png"))
        self.setPos(375, 275)
        self.speed = 5

        self.setScale(0.5)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_A:  # Лево (A)
            self.moveBy(-self.speed, 0)
        elif event.key() == Qt.Key_D:  # Право (D)
            self.moveBy(self.speed, 0)
        elif event.key() == Qt.Key_W:  # Вверх (W)
            self.moveBy(0, -self.speed)
        elif event.key() == Qt.Key_S:  # Вниз (S)
            self.moveBy(0, self.speed)
