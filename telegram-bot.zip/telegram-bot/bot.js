const TelegramBot = require('node-telegram-bot-api');
const token = '5932611213:AAH5UEnej4KjWg3UpofCAfz8oKjKucQtT8w'; 

const bot = new TelegramBot(token, { polling: true });
const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('players.db', (err) => {
  if (err) {
    console.error(err.message);
  } else {
    console.log('Connected to the players database.');

 db.run(`CREATE TABLE IF NOT EXISTS players (
      id INTEGER PRIMARY KEY,
      user_id INTEGER NOT NULL,
      nickname TEXT NOT NULL,
      balance INTEGER NOT NULL,
      married INTEGER NOT NULL,
      coins_lost INTEGER NOT NULL,
      coins_won INTEGER NOT NULL,
      max_bet INTEGER NOT NULL
    )`);

db.run(`CREATE TABLE IF NOT EXISTS player_history (
      id INTEGER PRIMARY KEY,
      player_id INTEGER NOT NULL,
      chat_id INTEGER NOT NULL,
      message TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

  db.run(`CREATE TABLE IF NOT EXISTS player_logs (
      id INTEGER PRIMARY KEY,
      player_id INTEGER NOT NULL,
      chat_id INTEGER NOT NULL,
      log_message TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
  }
});

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 'Добро пожаловать! Чтобы сделать ставку, используйте команду /bet <сумма> <цвет/число>.');
});

bot.onText(/\/balance/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const getBalanceQuery = `
    SELECT balance
    FROM players
    WHERE user_id = ?
  `;
  db.get(getBalanceQuery, [userId], (err, row) => {
    if (err) {
      console.error(err.message);
      return;
    }

    const balance = row ? row.balance : 0;
    bot.sendMessage(chatId, `Ваш баланс: ${balance} монет.`);
  });
});

bot.onText(/\/history/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

 const getHistoryQuery = `
    SELECT message
    FROM player_history
    WHERE player_id = ? AND chat_id = ?
  `;
  db.all(getHistoryQuery, [userId, chatId], (err, rows) => {
    if (err) {
      console.error(err.message);
      return;
    }

    let historyMessage = "История транзакций:\n\n";
    rows.forEach((row) => {
      historyMessage += `${row.message}\n`;
    });

    bot.sendMessage(chatId, historyMessage);
  });
});

bot.onText(/\/bet (\d+) (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const amount = parseInt(match[1]);
  const betType = match[2].toLowerCase();

  const insertBetQuery = `
    INSERT INTO player_history (player_id, chat_id, message)
    VALUES (?, ?, ?)
  `;
  db.run(insertBetQuery, [userId, chatId, `Ставка: ${amount} монет на ${betType}`], (err) => {
    if (err) {
      console.error(err.message);
    }
  });

});

bot.onText(/\/bet (\d+) (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const amount = parseInt(match[1]);
  const betType = match[2].toLowerCase();

const insertBetQuery = `
    INSERT INTO player_history (player_id, chat_id, message)
    VALUES (?, ?, ?)
  `;
  db.run(insertBetQuery, [userId, chatId, `Ставка: ${amount} монет на ${betType}`], (err) => {
    if (err) {
      console.error(err.message);
    }
  });

});

bot.startPolling();

bot.onText(/\/bet (\d+) (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const amount = parseInt(match[1]);
  const betType = match[2].toLowerCase();

 if (isNaN(amount) || amount <= 0) {
    bot.sendMessage(chatId, "Неверная сумма ставки.");
    return;
  }

  if (!colors.includes(betType) && !numbers.includes(betType)) {
    bot.sendMessage(chatId, "Недопустимый тип ставки.");
    return;
  }

const updateBalanceQuery = `
    UPDATE players
    SET balance = balance - ?
    WHERE user_id = ?
  `;
  db.run(updateBalanceQuery, [amount, userId], (err) => {
    if (err) {
      console.error(err.message);
      return;
    }

  const insertBetQuery = `
      INSERT INTO player_history (player_id, chat_id, message)
      VALUES (?, ?, ?)
    `;
    db.run(insertBetQuery, [userId, chatId, `Ставка: ${amount} монет на ${betType}`], (err) => {
      if (err) {
        console.error(err.message);
      }
    });

    bot.sendMessage(chatId, `Ставка принята. Сумма: ${amount} монет, Тип: ${betType}`);
  });
});

bot.startPolling();
const fs = require('fs');

const dbFilePath = 'players.db';

if (!fs.existsSync(dbFilePath)) {
  console.log('Creating new database file...');
  fs.closeSync(fs.openSync(dbFilePath, 'w'));
}

