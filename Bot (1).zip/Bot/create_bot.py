from aiogram import Bot
from aiogram.dispatcher import Dispatcher
import os
from aiogram.contrib.fsm_storage.memory import MemoryStorage

storage = MemoryStorage()
bot = Bot(token="5932611213:AAG2K18krrp1zL7EB8g1gqlwxwuPngnQfQY")
dp = Dispatcher(bot, storage=storage)