import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel

class MyWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Привет!")
        self.setGeometry(100, 100, 300, 150)

        self.message_label = QLabel(self)
        self.message_label.setText("Вадик лох :) Никита и я тоже")
        self.message_label.setGeometry(50, 50, 200, 30)

    def show_message(self):
        self.message_label.setText("Вадик лох :)")

app = QApplication(sys.argv)
window = MyWindow()
window.show()
sys.exit(app.exec_())


