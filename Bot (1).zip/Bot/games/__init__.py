from games import roulettez, slots, cancel_bid
from games import arithmetic