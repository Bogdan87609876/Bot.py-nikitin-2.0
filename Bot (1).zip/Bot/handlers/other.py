from aiogram import types, Dispatcher
from create_bot import dp

# эхо
@dp.message_handler()
async def echo_send(message : types.Message):
    await message.answer(message.text)

